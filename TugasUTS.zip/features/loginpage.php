<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../css/loginpagestyle.css" />
  </head>
  <body>
  <?php
    include("../modular/headerBack.php");
    ?>

    <!-- Spacer -->
    <div style="height: 100px"></div>

    <!-- Background Image -->
    <img class="background" src="../img/logo/rakbuku.jpg" alt="Background Rak Buku" />

    <!-- Login Container -->
    <div class="tempatlogin">
      <div class="loginbackground"></div>
      <div class="login-container">
        <input type="email" placeholder="Email" required />
        <input
          class="password"
          type="password"
          placeholder="Password"
          required
        />
        <button class="button login-button">Login</button>
        <p class="signin" style="color: white">
          Belum punya akun?
          <a href="signuppage.php">
            <button class="button">Sign-Up</button>
          </a>
        </p>
      </div>

      <!-- Opsi Login -->
      <div class="opsilogin">
        <p style="color: white">Atau login dengan:</p>
        <div class="social-login">
          <button style="background-color: white">
            <img class="ikon" src="../img/logo/google.png" alt="Google Logo" /> Google
          </button>
          <button style="background-color: white">
            <img class="ikon" src="../img/logo/facebook logo.png" alt="Facebook Logo" />
            Facebook
          </button>
          <button style="background-color: white">
            <img class="ikon" src="../img/logo/whatsapp.jpg" alt="WhatsApp Logo" />
            WhatsApp
          </button>
        </div>
      </div>
    </div>

    <script src="../bootstrap/js/bootstrap.min.js"></script>


  </body>
</html>
