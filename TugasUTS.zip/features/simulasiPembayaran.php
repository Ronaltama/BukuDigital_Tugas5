<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Pembayaran</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css" />
  <!-- Custom CSS -->
  <link rel="stylesheet" href="../style.css" />
  <style>
  .buttonberanda {
    background-color: #ffc107;
    border-radius: 5px;
    width: 100px;
    height: 40px;
  }

  * {
    box-sizing: border-box;
    font-family: Arial, sans-serif;
  }

  .main-container {
    max-width: 1000px;
    margin: 0 auto;
  }

  .section {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
  }

  h2 {
    color: #ffc107;
    margin-top: 0;
  }

  .form-group {
    margin-bottom: 15px;
  }

  label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
  }

  input,
  select {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
  }

  .result {
    margin-top: 20px;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 4px;
  }

  .result p {
    margin: 5px 0;
  }

  .book-selectors {
    display: none;
  }

  .button {
    background: #ffc107;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    cursor: pointer;
    width: 100%;
    margin-top: 15px;
  }

  .button:hover {
    background: #c19206;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
  }

  th,
  td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
  }

  th {
    background-color: #f8f9fa;
    font-weight: bold;
  }

  tr:hover {
    background-color: #f5f5f5;
  }
  </style>
</head>

<body>
  <?php
    include("../modular/headerBack.php");
    ?>
  <!-- Konten utama menggunakan kelas .main-container -->
  <div class="main-container">
    <!-- Transaction Form -->
    <div class="section">
      <h2>Pembayaran</h2>
      <div class="form-group">
        <label>Jenis Transaksi: Sewa</label>
        <select id="transaction-type">
          <option value="rental">Sewa</option>
        </select>
      </div>

      <div class="form-group">
        <label>Nama :</label>
        <input type="text" id="member-name" />
      </div>

      <div class="form-group">
        <label>Total Buku:</label>
        <input type="number" id="book-quantity" min="1" />
      </div>
      <div id="book-selectors" class="book-selectors">
        <!-- Book selectors will be generated here -->
      </div>

      <!-- Input Durasi -->
      <div class="form-group">
        <label>Durasi (dalam minggu):</label>
        <input type="number" id="duration" min="1" />
      </div>

      <!-- Input Voucher -->
      <div class="form-group">
        <label>Kode Voucher:</label>
        <input type="text" id="voucher-code" />
      </div>

      <div class="form-group">
        <label>Payment Method:</label>
        <select id="payment-method">
          <option value="">Silakan pilih metode pembayaran</option>
          <option value="transfer">Bank Transfer</option>
          <option value="ewallet">E-Wallet</option>
        </select>
      </div>

      <div class="result">
        <p>Subtotal: Rp. <span id="subtotal">0</span></p>
        <p>Admin: Rp. <span id="admin-fee">0</span></p>
        <p>Voucher Potongan: Rp. <span id="voucher-discount">0</span></p>
        <p>Total Pembayaran: Rp. <span id="total-payment">0</span></p>
      </div>
      <button class="button" onclick="submitTransaction()">
        Submit Transaction
      </button>
    </div>

    <!-- History Section -->
    <div class="section">
      <h2>Riwayat Transaksi</h2>
      <table>
        <thead>
          <tr>
            <th>Tanggal</th>
            <th>Nama</th>
            <th>Buku</th>
            <th>Durasi</th>
            <th>Voucher</th>
            <th>Pembayaran</th>
            <th>Subtotal</th>
            <th>Admin</th>
            <th>Diskon</th>
            <th>Total Pembayaran</th>
          </tr>
        </thead>
        <tbody id="history-table">
          <!-- Transaction history will be added here -->
        </tbody>
      </table>
    </div>
  </div>

  <script>
  // Book prices (Rental prices for 1 week)
  const BOOK_PRICES = {
    rental: {
      Bulan: 10000,
      "Cantik itu Luka": 15000,
      Amba: 15000,
      "Laskar Pelangi": 15000,
      Hujan: 10000,
      "Luka Cita": 20000,
      "Filosofi Teras": 34000,
      "Sisi Tergelap Surga": 50000,
      "You do You": 30000,
      "Gadis Kretek": 25000,
    },
  };

  // Admin fees
  const ADMIN_FEES = {
    transfer: 2000,
    ewallet: 2500,
  };

  // Voucher discounts (hardcoded)
  const VOUCHER_DISCOUNTS = {
    DISCOUNT10: 0.1, // 10% discount
    HALFPRICE: 0.5, // 50% discount
    DIGI20: 0.2, // 20% discount
    GEMARMEMBACA: 0.1, // 10% discount
  };

  // Fungsi untuk menghitung perhitungan pembayaran
  function calculatePayment() {
    const transactionType =
      document.getElementById("transaction-type").value;
    const duration =
      parseInt(document.getElementById("duration").value) || 1;
    const payment = document.getElementById("payment-method").value;
    const voucherCode = document
      .getElementById("voucher-code")
      .value.trim();
    let subtotal = 0;
    const selectors = document.querySelectorAll(".book-select");
    selectors.forEach((selector) => {
      if (selector.value) {
        subtotal += BOOK_PRICES[transactionType][selector.value];
      }
    });
    subtotal *= duration;
    const adminFee = payment ? ADMIN_FEES[payment] : 0;
    let voucherDiscount = 0;
    if (voucherCode && VOUCHER_DISCOUNTS[voucherCode]) {
      voucherDiscount = subtotal * VOUCHER_DISCOUNTS[voucherCode];
    }
    const total = subtotal + adminFee - voucherDiscount;
    return {
      subtotal,
      adminFee,
      voucherDiscount,
      total
    };
  }

  // Update tampilan perhitungan secara real-time
  function updateCalculations() {
    const {
      subtotal,
      adminFee,
      voucherDiscount,
      total
    } =
    calculatePayment();
    document.getElementById("subtotal").textContent = subtotal;
    document.getElementById("admin-fee").textContent = adminFee;
    document.getElementById("voucher-discount").textContent =
      voucherDiscount;
    document.getElementById("total-payment").textContent = total;
  }

  // Generate book selectors berdasarkan jumlah buku yang dimasukkan
  function generateBookSelectors(quantity) {
    const container = document.getElementById("book-selectors");
    container.innerHTML = "";
    container.style.display = "block";
    for (let i = 1; i <= quantity; i++) {
      const div = document.createElement("div");
      div.className = "form-group";
      div.innerHTML = `
            <label>Book ${i}:</label>
            <select id="book-${i}" class="book-select">
              <option value="">Pilih judul buku</option>
              <option value="Bulan">Bulan</option>
              <option value="Cantik itu Luka">Cantik itu Luka</option>
              <option value="Amba">Amba</option>
              <option value="Hujan">Hujan</option>
              <option value="Laskar Pelangi">Laskar Pelangi</option>
              <option value="Luka Cita">Luka Cita</option>
              <option value="Filosofi Teras">Filosofi Teras</option>
              <option value="Sisi Tergelap Surga">Sisi Tergelap Surga</option>
              <option value="You do You">You do You</option>
              <option value="Gadis Kretek">Gadis Kretek</option>
            </select>
          `;
      container.appendChild(div);
    }
    // Tambahkan event listener untuk setiap book selector
    const selectors = document.querySelectorAll(".book-select");
    selectors.forEach((selector) => {
      selector.addEventListener("change", updateCalculations);
    });
  }

  // Submit transaksi dan tambahkan ke riwayat
  function submitTransaction() {
    const member = document.getElementById("member-name").value;
    const duration = document.getElementById("duration").value;
    const voucher = document.getElementById("voucher-code").value;
    const payment = document.getElementById("payment-method").value;
    const selectors = document.querySelectorAll(".book-select");
    let books = [];
    selectors.forEach((selector) => {
      if (selector.value) books.push(selector.value);
    });
    // Hitung kembali untuk mendapatkan detail perhitungan
    const {
      subtotal,
      adminFee,
      voucherDiscount,
      total
    } =
    calculatePayment();
    addToHistory(
      member,
      books.join(", "),
      duration,
      voucher,
      payment,
      subtotal,
      adminFee,
      voucherDiscount,
      total
    );
    resetForm();
  }

  // Tambahkan transaksi ke riwayat dengan detail lengkap
  function addToHistory(
    member,
    books,
    duration,
    voucher,
    payment,
    subtotal,
    adminFee,
    voucherDiscount,
    total
  ) {
    const table = document.getElementById("history-table");
    const row = table.insertRow(0);
    row.innerHTML = `
          <td>${new Date().toLocaleDateString()}</td>
          <td>${member}</td>
          <td>${books}</td>
          <td>${duration} minggu</td>
          <td>${voucher}</td>
          <td>${payment}</td>
          <td>Rp. ${subtotal}</td>
          <td>Rp. ${adminFee}</td>
          <td>Rp. ${voucherDiscount}</td>
          <td>Rp. ${total}</td>
        `;
  }

  // Reset form ke kondisi awal
  function resetForm() {
    document.getElementById("transaction-type").value = "rental";
    document.getElementById("member-name").value = "";
    document.getElementById("book-quantity").value = "";
    document.getElementById("duration").value = "";
    document.getElementById("voucher-code").value = "";
    document.getElementById("payment-method").value = "";
    document.getElementById("book-selectors").style.display = "none";
    document.getElementById("subtotal").textContent = "0";
    document.getElementById("admin-fee").textContent = "0";
    document.getElementById("voucher-discount").textContent = "0";
    document.getElementById("total-payment").textContent = "0";
  }

  // Event listeners
  document
    .getElementById("book-quantity")
    .addEventListener("input", function() {
      generateBookSelectors(this.value);
      updateCalculations();
    });
  document
    .getElementById("voucher-code")
    .addEventListener("input", updateCalculations);
  document
    .getElementById("duration")
    .addEventListener("input", updateCalculations);
  document
    .getElementById("payment-method")
    .addEventListener("change", updateCalculations);
  </script>

  <?php
    include("../modular/footerFitur.php");
    ?>
</body>

</html>