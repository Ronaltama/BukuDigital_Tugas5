<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sign-up</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../css/loginpagestyle.css" />
  </head>
  <body>
  <?php
    include("../modular/headerBack.php");
    ?>
    <!-- Tambahan spacing agar konten tidak tertutup header -->
    <div style="margin-top: 100px"></div>
    <!-- Content -->
    <img class="background" src="../img/logo/rakbuku.jpg" alt="Rak Buku" />
    <div class="tempatlogin">
      <div class="loginbackground"></div>
      <div class="login-container">
        <form>
          <input type="email" placeholder="Alamat Email" required />
          <br /><br />
          <input type="text" placeholder="Username" required />
          <br /><br />
          <input type="password" placeholder="Password" required />
          <br /><br />
          <input type="password" placeholder="Konfirmasi Password" required />
          <br /><br />
          <div class="form-check form-check-inline">
            <input
              class="form-check-input"
              type="checkbox"
              id="agree"
              required
            />
            <label class="form-check-label" for="agree">
              Saya setuju dengan semua persyaratan yang telah disebutkan
            </label>
          </div>
          <br>
          <button class="button login-button" type="submit">Sign-up</button>
        </form>
      </div>
    </div>

  </body>
</html>
